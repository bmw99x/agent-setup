import html
import re
import warnings

import htmlsan

from mdrender._html import escape_attribute as escape_attr


def render(text: str, *, sanitize: bool | None = None, safe: bool | None = None, extensions=()) -> str:
    """Render Markdown to HTML. With sanitize=True the output is passed through htmlsan."""
    if safe is not None:
        warnings.warn("render(safe=) is deprecated; use sanitize=", DeprecationWarning, stacklevel=2)
    if sanitize is None:
        sanitize = True if safe is None else safe
    rendered = _blocks(text, extensions)
    return htmlsan.clean(rendered) if sanitize else rendered


def render_inline(text: str) -> str:
    return _inline(text)


def _inline(text: str) -> str:
    text = html.escape(text)
    text = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\*(.+?)\*", r"<em>\1</em>", text)
    return re.sub(r"\[(.+?)\]\((.+?)\)", lambda m: f"<a href=\"{escape_attr(m.group(2))}\">{m.group(1)}</a>", text)


def _blocks(text: str, extensions) -> str:
    out = []
    for block in (b.strip() for b in text.split("\n\n") if b.strip()):
        if block.startswith("<"):
            out.append(block)
        elif block.startswith("#"):
            level = len(block) - len(block.lstrip("#"))
            out.append(f"<h{level}>{_inline(block[level:].strip())}</h{level}>")
        else:
            out.append(f"<p>{_inline(block)}</p>")
    rendered = "\n".join(out)
    for extension in extensions:
        rendered = extension.transform(rendered)
    return rendered
