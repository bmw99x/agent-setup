import html
import re

_TAG = re.compile(r"</?([a-zA-Z0-9]+)[^>]*>")


def clean(markup: str, allow: frozenset[str] = frozenset({"p", "a", "em", "strong", "ul", "ol", "li"})) -> str:
    """Strip every tag not in `allow`."""
    return _TAG.sub(lambda m: m.group(0) if m.group(1).lower() in allow else "", markup)


def escape(text: str) -> str:
    return html.escape(text)
