def utc_offset(zone: str) -> int:
    return 0
