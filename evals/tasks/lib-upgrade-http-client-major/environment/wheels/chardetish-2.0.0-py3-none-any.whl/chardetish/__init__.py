def detect(data: bytes) -> str:
    """Guess the text encoding of `data`."""
    try:
        data.decode("utf-8")
    except UnicodeDecodeError:
        return "cp1252"
    return "utf-8"
