import ssl


def where() -> str | None:
    """Path to the CA certificates bundle."""
    return ssl.get_default_verify_paths().cafile
